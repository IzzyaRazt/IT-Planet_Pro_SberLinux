# Установка PIP пакета
    pip install watchdog

# Запуск проекта