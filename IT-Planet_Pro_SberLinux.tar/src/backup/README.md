# Установка PIP пакета
    pip install schedule

# Запуск проекта