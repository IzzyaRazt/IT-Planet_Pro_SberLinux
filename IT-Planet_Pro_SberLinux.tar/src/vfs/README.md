# Установка PIP пакета
    pip install paramiko

# Запуск проекта
    run /YOU_PAHT/python ssh_server.py