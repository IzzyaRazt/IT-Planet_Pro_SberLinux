# Установка PIP пакета
    pip install fusepy

# Запуск проекта
    mkdir /tmp/memoryfs
    python vfs.py /tmp/memoryfs